<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] = "Travels";
$route['addplan'] = "Travels/addplan";
$route['logout'] = "Travels/logout";
// $route['process_form'] = "Surveys/process_form";
$route['404_override'] = '';


/* End of file routes.php */
/* Location: ./application/config/routes.php */