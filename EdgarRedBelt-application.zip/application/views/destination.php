<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Destination</title>
</head>
<body>
	<div id="container">
		<p><a href="">Home</a></p>
		<p><a href="">Logout</a></p>

		<h4>Destination</h4>
			get info 


		Other users on this trip
	</div>
</body>
</html>